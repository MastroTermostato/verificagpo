const f=require('./verifica.js');

test('offusca', () => {

    expect(f.offusca('abolite')).toBe('480L173');
    expect(f.offusca('abolitea')).toBe('480L1734');
    expect(f.offusca('s')).toBe('S');
    expect(f.offusca('s s')).toBe('S S');

});

test('calcola', () => {

    expect(f.calcola('sin(x) + 1', 1.5)).toBe(1.9974949866040546);
    expect(f.calcola('x^2 + 1', 1.5)).toBe(3.25);

});

