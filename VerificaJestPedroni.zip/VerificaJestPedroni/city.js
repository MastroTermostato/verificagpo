// filename city.js

// Cerca nell'archivio fornito il nome indicato.
// Parametro archivio: lista di stringhe.
// Parametro nome: stringa da cercare.
// Restituisce true se il nome è presente, false altrimenti.
// Se anche solo uno dei parametri è null la funzione restituisce false.

function cerca(archivio, nome) {
    if (archivio == null || nome == null) {
        return false;
    }
    for (i=0; i<archivio.length; i++) {
        if (archivio[i] == nome) {
            return true;
        }
    }
    return false;
}

module.exports = { cerca };
